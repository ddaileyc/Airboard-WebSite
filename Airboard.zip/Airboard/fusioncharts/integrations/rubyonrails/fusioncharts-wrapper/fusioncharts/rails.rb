module Fusioncharts
  module Rails

  end
end
